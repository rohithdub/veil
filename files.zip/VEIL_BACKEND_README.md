# VEIL Backend — Setup & API Reference

## Quick Start

```bash
# 1. Install dependencies
pip install flask flask-cors flask-limiter requests PyJWT cryptography

# 2. Configure environment
cp .env.example .env
# Edit .env — set VEIL_AI_KEY and change VEIL_SECRET_KEY + VEIL_ADMIN_PASS

# 3. Run
python server.py
```

Server starts at **http://localhost:5000**  
On first run, the admin API key is printed to the console — save it.

---

## Architecture

```
VEIL.html (frontend)
    │
    ▼  HTTP / JSON
VEIL Backend (server.py)           Flask + SQLite
    ├── /api/auth/*                JWT authentication
    ├── /api/scan                  URL scan + AI proxy
    ├── /api/history/*             Per-user scan history
    ├── /api/reports               Community reports
    ├── /api/admin/*               Admin dashboard
    └── /api/health                Health check
         │
         ▼  HTTP (server-side, key never exposed to browser)
    AI Provider (Anthropic / OpenAI / Ollama / Groq / any)
```

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `VEIL_SECRET_KEY` | random | JWT signing secret — set a long random string in production |
| `VEIL_ADMIN_USER` | `admin` | Admin username |
| `VEIL_ADMIN_PASS` | `veil-change-me` | Admin password — **change this** |
| `VEIL_AI_URL` | Anthropic endpoint | AI API endpoint |
| `VEIL_AI_KEY` | _(empty)_ | AI API key — kept server-side, never sent to browser |
| `VEIL_AI_MODEL` | `claude-sonnet-4-20250514` | Model name |
| `VEIL_AI_FORMAT` | `anthropic` | `anthropic` or `openai` |
| `PORT` | `5000` | Listen port |
| `TOKEN_TTL_HOURS` | `24` | JWT expiry in hours |

---

## API Reference

### Authentication

#### `POST /api/auth/register`
Create a new account.
```json
{ "username": "alice", "email": "alice@example.com", "password": "secure123" }
```
Returns: `{ token, api_key, user }`

#### `POST /api/auth/login`
```json
{ "username": "alice", "password": "secure123" }
```
Returns: `{ token, api_key, user }`

#### `GET /api/auth/me`
Returns current user profile. Requires auth.

#### `POST /api/auth/apikey/rotate`
Generate a new API key. Requires auth.

**Auth options for all protected endpoints:**
- Header: `Authorization: Bearer <jwt_token>`
- Header: `X-API-Key: veil_<key>`
- Query:  `?api_key=veil_<key>`

---

### URL Scan

#### `POST /api/scan`
Scan a URL for trust signals. Auth optional (anonymous scans allowed).
```json
{
  "url": "https://example.com",
  "serverCfg": {
    "url": "https://api.anthropic.com/v1/messages",
    "model": "claude-sonnet-4-20250514",
    "format": "anthropic"
  }
}
```
- Results cached for 1 hour per URL
- Community report counts merged into response
- AI key always comes from server `.env` — client `serverCfg.key` is ignored

Returns full trust analysis JSON.

---

### Scan History

#### `GET /api/history?limit=20`
User's scan history. Requires auth.

#### `GET /api/history/<scan_id>`
Full detail of a single scan. Requires auth.

#### `DELETE /api/history/<scan_id>`
Delete one history entry. Requires auth.

#### `DELETE /api/history`
Clear all history for the user. Requires auth.

---

### Reports

#### `POST /api/reports`
Submit a community report. Auth optional.
```json
{ "url": "https://suspicious.com", "type": "scam", "details": "optional notes" }
```
Types: `scam`, `phishing`, `fake`, `manipulation`, `malware`, `other`  
Duplicate prevention: same IP + URL + type within 24h is rejected.

#### `GET /api/reports?url=<url>`
List reports for a URL. Auth required.

---

### Admin

All admin routes require auth + `admin` role.

#### `GET /api/admin/stats`
System-wide stats: user count, scan count, top scanned URLs, recent reports.

#### `GET /api/admin/users`
List all users.

#### `PATCH /api/admin/reports/<id>`
Update report status: `{ "status": "reviewed" | "actioned" | "dismissed" }`

---

### Utility

#### `GET /api/health`
Health check — DB status, AI config, timestamp.

#### `GET /api/config/server`
Public server config (no secrets) — used by frontend auto-detect.

---

## Security Features

| Feature | Implementation |
|---|---|
| Password hashing | PBKDF2-HMAC-SHA256, 260,000 iterations, per-user salt |
| JWT tokens | HS256, configurable TTL, issued/expiry claims |
| API keys | SHA-256 hashed in DB, never stored plain |
| Rate limiting | 200/hour global, 30/min global, 60/hour on scan, 10/hour on register |
| CORS | Configurable origins |
| Security headers | X-Content-Type-Options, X-Frame-Options, Referrer-Policy, XSS-Protection |
| Brute-force delay | 500ms delay on failed login |
| Input validation | URL regex validation, length limits on all fields |
| SQL injection | All queries use parameterized statements |
| Report spam | IP + URL + type dedup within 24h |
| AI key isolation | API key lives in `.env`, never reaches the browser |

---

## Production Checklist

- [ ] Set a strong random `VEIL_SECRET_KEY`
- [ ] Change `VEIL_ADMIN_PASS`
- [ ] Set your real `VEIL_AI_KEY`
- [ ] Run behind a reverse proxy (nginx / Caddy) with HTTPS
- [ ] Set `CORS` origins to your actual domain instead of `*`
- [ ] Use a process manager: `gunicorn server:app` or `systemd`
- [ ] Set up log rotation for `veil.db` backups

```bash
# Production with gunicorn
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 server:app
```
